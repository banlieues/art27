<button type="button" class="btn-translator btn btn-sm p-0 ms-1">
    <small> <?php echo fontawesome('tumblr-square');?> </small>
</button>